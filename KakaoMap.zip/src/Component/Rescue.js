const Rescue = () => {
    return (
        <p>응급처지 방법 소개 페이지</p>
    );
}

export default Rescue;