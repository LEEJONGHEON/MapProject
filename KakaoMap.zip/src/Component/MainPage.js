const MainPage = () => {
    return (
        <p>메인 페이지</p>
    );
}

export default MainPage;